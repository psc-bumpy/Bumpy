import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.LinkedList;

public class GPS_position {
	double longitude;
	double latitude;
	
	private final static double R = 6400000.0;
	private final static double limite_longitude = 5*360/(2*Math.PI*R);
	
	// attention : il faut que les minutes de degr� aient �t� converties en degr� avant ce code
	// OU : constructeur GPS_position(String[] s) et on utilise les s�parateurs � et '
	// pour faire un calcul qui ram�ne tout en degr�
	
	GPS_position(double longi, double lat){
		this.longitude = longi;
		this.latitude = lat;
	}
	
	GPS_position(double[] position){
		// il faudra mettre une exception si la longueur du tableau position est diff�rente de 2
		this.longitude=position[0];
		this.latitude=position[1];
	}
	
	//CONSTRUCTEUR AVEC UN STRING (POUR GPS ISSU DE LA BDD)
	
	GPS_position(String s){
		
		boolean conforme = false;
		for (int j = 0;j<s.length();j++){
			if (s.charAt(j)==','){conforme = true;}
		}
		
		if (conforme){
			
		int i = 0;
		char c = s.charAt(i);
		String longi = "";
		while (c!=','){
			longi = longi + c;
			i++;
			c=s.charAt(i);
		}

		i++;
		String lat ="";
		while (i<s.length()){
			lat = lat+s.charAt(i);
			i++;
		}
		
		this.longitude = Double.parseDouble(longi);
		this.latitude = Double.parseDouble(lat);
		}
		
		else{this.longitude = 0;this.latitude = 0;}
	}
	
	String BdDtoString(){
		return ""+this.longitude+""+","+""+this.latitude+"";
	}
	
	//REGARDER SI 2 POSITIONS GPS SONT A PEU PRES EGALES
	
	boolean isEqual(GPS_position p2){
		double diff_long = this.longitude-p2.longitude;
		double diff_lat = this.latitude-p2.latitude;
		if (Math.abs(diff_long) < limite_longitude){
			double longitude_moyenne = (this.longitude+p2.longitude)*0.5;
			double limite_latitude = (5*360)/(2*Math.PI*R*Math.cos(longitude_moyenne*(Math.PI*180)));
			if (Math.abs(diff_lat) < limite_latitude){
				return true;
			}
		}
		return false;
	}
	
	//REGARDER SI UNE POSITION GPS EST DEJA PRESENTE DANS LA BDD
	
	boolean isPresent(){
		String url = "jdbc:postgresql://localhost:5432/PSCMEC12 X2015 PSA";
		String login = "postgres";
		String password = "pscmec12";
		Connection cn = null;
		try{
			Class.forName("org.postgresql.Driver");     
			cn = DriverManager.getConnection(url, login, password);   
			String sql = "SELECT coordonnees_gps FROM gps_position";
			Statement st = cn.createStatement();
			//R�cup�ration des positions Gps d�j� existantes
			ResultSet res = st.executeQuery(sql);
			
			while (res.next()){
				GPS_position gps = new GPS_position(res.getString("coordonnees_gps"));
				if (this.isEqual(gps)){
					return true;
				}
			}
					
			res.close();
			st.close();
			cn.close();
			
			System.out.println("La position cherch�e n'est pas pr�sente");
			return false;
					
		} 
				
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
	return false;
}
	
	// RECUPERER LE NUMERO D'UN OBSTACLE A UNE POSITION GPS DONNEE
	
	Integer num_obstacle(){
		String url = "jdbc:postgresql://localhost:5432/PSCMEC12 X2015 PSA";
		String login = "postgres";
		String password = "pscmec12";
		Connection cn = null;
		try{
			Class.forName("org.postgresql.Driver");
			cn = DriverManager.getConnection(url, login, password);
		
			String sql = "SELECT numero_obstacle FROM gps_position WHERE gps_position.coordonnees_gps=?";
			PreparedStatement st = cn.prepareStatement(sql);
			st.setString(1,this.BdDtoString());
			
			ResultSet res = st.executeQuery();
			res.next();
			Integer num_obstacle = res.getInt(1);
			
			res.close();
			st.close();
			cn.close();
			
			return num_obstacle;
		} 	
		catch (ClassNotFoundException e) {
				e.printStackTrace();
		} 
		catch (SQLException e) {
				e.printStackTrace();
		}
		return -1;
	}
	
	//RECUPERER LES TYPES DEJA TROUVES POUR UN OBSTACLE LOCALISE
	
	public type_obstacle type_obstacle(){
		if (this.isPresent())
		{
		Integer n = this.num_obstacle();
				
		String url = "jdbc:postgresql://localhost:5432/PSCMEC12 X2015 PSA";
		String login = "postgres";
		String password = "pscmec12";
		Connection cn = null;
		
		String s = "";
		try{
			Class.forName("org.postgresql.Driver");    
			cn = DriverManager.getConnection(url, login, password);   
		
			String sql1 = "SELECT type_obstacle FROM types_obstacles WHERE numero_obstacle = ?";
			PreparedStatement st1 = cn.prepareStatement(sql1);
			st1.setInt(1,n);
			ResultSet res1 = st1.executeQuery();
			res1.first();
			s = res1.getString(1);
			
			res1.close();
			st1.close();
			cn.close();
		}
		catch (ClassNotFoundException e) {
		      e.printStackTrace();
		    } 
		catch (SQLException e) {
		      e.printStackTrace();
		    }

		return new type_obstacle(s);
		}
		else{ 
			return new type_obstacle(new HashMap<String,Integer>());
		}
	}
	
	static LinkedList<GPS_position> Tous_les_points(){
		LinkedList<GPS_position> res = new LinkedList<GPS_position>();
		String url = "jdbc:postgresql://localhost:5432/PSCMEC12 X2015 PSA";
		String login = "postgres";
		String password = "pscmec12";
		Connection cn = null;
		try{
			Class.forName("org.postgresql.Driver");
			cn = DriverManager.getConnection(url, login, password);
		
			String sql = "SELECT coordonnees_gps FROM gps_position";
			PreparedStatement st = cn.prepareStatement(sql);
			ResultSet r = st.executeQuery();
			
			while (r.next()){
				res.add(new GPS_position(r.getString(1)));
			}
			
			r.close();
			st.close();
			cn.close();
			
		} 	
		catch (ClassNotFoundException e) {
				e.printStackTrace();
		} 
		catch (SQLException e) {
				e.printStackTrace();
		}
		return res;
	}
	
}
