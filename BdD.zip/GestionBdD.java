
import java.util.LinkedList;
import gallouedec.benoit.PSC.*;

public class GestionBdD {

	public static void Sauvegarder(){
		LinkedList<String> liste = B3Download.downloadThroughProxy("kuzh.polytechnique.fr",8080);
		for (String s : liste){
			Measure.Recuperer(s).save();
		}
	}
	
	public static void main(String[] args){
		Sauvegarder();
	}
	/*
	public static LinkedList<double[]> TousLesObstacles(){
		LinkedList<double[]> res = new LinkedList<double[]>();
		String url = "jdbc:postgresql://localhost:5432/PSCMEC12 X2015 PSA";
		String login = "postgres";
		String password = "pscmec12";
		Connection cn = null;
		try{
			Class.forName("org.postgresql.Driver");
			cn = DriverManager.getConnection(url, login, password);
			
			/* JOINTURE ?
			String sql = "SELECT coordonnees_gps,num_mesures FROM gps_position JOIN nombre_mesures  ON numero_obstacle = numero_obstacle";
			*/
			/*
			String sql = "SELECT * FROM nombre_mesures";
			Statement st = cn.createStatement();
			ResultSet r = st.executeQuery(sql);
			while (r.next()){
				GPS_position gps = r.getString(1).trouvercoordonnees());
				res.add(new double[]{gps.latitude);
			}
			
			r.close();
			st.close();
			cn.close();
			
		} 	
		catch (ClassNotFoundException e) {
				e.printStackTrace();
		} 
		catch (SQLException e) {
				e.printStackTrace();
		}
		return res;
	}
	}
	*/
}
