import java.util.HashMap;
import java.util.Map.Entry;

public class type_obstacle {
	public HashMap<String,Integer> types;
	
	//CONSTRUCTEUR AVEC HASHMAP DIRECT
	type_obstacle(HashMap<String,Integer> h){
		this.types = h;
	}
	
	//CONSTRUCTEUR A PARTIR DE LA BDD OU D'UN STRING RENVOYE PAR UN PROGRAMME
	//il faut que le String soit conforme (renvoyer exception sinon ?)
	type_obstacle(String s){
		String[] t = s.split("#");
		String[] Un_type;
		HashMap<String,Integer> types = new HashMap<String,Integer>();
		for (int i = 0;i<t.length;i++){
			Un_type = t[i].split(" ");
			types.put(Un_type[0],Integer.parseInt(Un_type[1]));
		}
		this.types=types;
	}
	
	//RENVOIE LE TYPE LE PLUS PROBABLE
	public String type_r�el(){
		String res = "";
		int m = 0;
		for (Entry<String,Integer> e : this.types.entrySet()){
			if (e.getValue()>m){
				res = e.getKey();
				m = e.getValue();
			}
		}
		return res;
	}
	
	//RENVOIE LA PROBA DU TYPE LE PLUS PROBABLE
	public double proba_type_r�el(){
		int total = 0;
		for (Entry<String, Integer> e : this.types.entrySet()){
			total = total + e.getValue();
		}
		return types.get(type_r�el())*1.0/total;
	}
	
	//TRANSFORME UNE HASHMAP EN UN STRING METTABLE DANS LA BDD
	public String type_toString(){
			HashMap<String,Integer> manip = this.types;
			String res = "";
			for (Entry<String, Integer> e : manip.entrySet()){
				res = res + e.getKey() + " " + e.getValue() + "#";
			}
			return res;
	}
	
	
	
}
