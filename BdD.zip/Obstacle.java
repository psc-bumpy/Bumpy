import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;

public class Obstacle {
	type_obstacle type_obstacle;
	GPS_position gps;
	
	//CONSTRUCTEUR POUR OBSTACLE A PARTIR D'UNE MESURE
	Obstacle(type_obstacle Type, GPS_position gps){
		this.type_obstacle = Type;
		this.gps = gps;
	}
	
	//CONSTRUCTEUR POUR OBSTACLE A PARTIR DE CE QUI EST DANS LA BDD
	Obstacle(GPS_position gps){
		this.type_obstacle = gps.type_obstacle();
		this.gps = gps;
	}
	
	//RENVOIE LE TYPE LE PLUS PROBABLE
	public String type_r�el(){
		return this.type_obstacle.type_r�el();
	}
	
	//COMPARE LES TYPES DE 2 OBSTACLES
	public boolean compare_type_obstacles(Obstacle Obs){
		return this.type_r�el().equals(Obs.type_r�el());
	}
	
	//RECUPERE LES MESURES FAITES SUR UN MEME OBSTACLE
	public LinkedList<Measure> mesures_obstacle(){
		LinkedList<Measure> res = new LinkedList<Measure>();
		Integer n = this.gps.num_obstacle();
		String url = "jdbc:postgresql://localhost:5432/PSCMEC12 X2015 PSA";
		String login = "postgres";
		String password = "pscmec12";
		Connection cn = null;
		try{
			Class.forName("org.postgresql.Driver");    
			cn = DriverManager.getConnection(url, login, password);
			
			String sql1 = "SELECT accelz,accelx,accely,mesures_temps,date FROM mesures WHERE numero_obstacle = ?";
			PreparedStatement st1 = cn.prepareStatement(sql1);
			st1.setInt(1, n);
			ResultSet res2 = st1.executeQuery();
			while(res2.next()){
				res.add(new Measure(res2.getString(5),gps,res2.getString(2), res2.getString(3), res2.getString(1), res2.getString(4)));
			}
			res2.close();
			st1.close();
			cn.close();
		}
		catch (ClassNotFoundException e) {
		      e.printStackTrace();
		    } 
		catch (SQLException e) {
		      e.printStackTrace();
		    }
		
		return res;
	}
	
}
