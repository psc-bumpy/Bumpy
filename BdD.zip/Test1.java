import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class Test1 {

	public static void main(String[] args) {
		GPS_position gps1 = new GPS_position(12.0, 2.0);
		GPS_position gps2 = new GPS_position(new double []{15.0, 112.0});
		GPS_position gps3 = new GPS_position(11.0, 11.0);
		
		Measure m1 = new Measure("19janvier2017",gps1, "1,4","1,3","1,3","0.04, 0.06");
		Measure m2 = new Measure("20janvier2017",gps2, "0,0.1,0,0,0", "0,0,0,0,0", "0,0.7,1.5,0.6,0.7","0.01,0.01,0.01,0.01,0.01");
		Measure m3 = new Measure("21janvier2017",gps3, "10,200","10,20","10,20","35,45");
		Measure m4 = new Measure("23janvier2017",gps3, "12,300","12,30","12,30","12,30");

		m1.save();
		m2.save();
		m3.save();
		m4.save();
		
		//Acces BdD
		String url = "jdbc:postgresql://localhost:5432/PSCMEC12 X2015 PSA";
		String login = "postgres";
		String password = "pscmec12";
		Connection cn = null;
				
		try{
					//chargement driver
					Class.forName("org.postgresql.Driver");
					//R�cup�ration connection     
					cn = DriverManager.getConnection(url, login, password);   
					//Cr�ation d'un objet PrepareStatement
					String sql = "SELECT * FROM gps_position";
					String sql2 = "SELECT * FROM nombre_mesures";
					Statement st = cn.createStatement();
					Statement st2 = cn.createStatement();
					
					ResultSet res = st.executeQuery(sql);
					ResultSet res2 = st2.executeQuery(sql2);
					ResultSetMetaData metadata = res.getMetaData();
					ResultSetMetaData metadata2 = res2.getMetaData();
					while (res.next()){
						for (int i = 1; i<metadata.getColumnCount();i++){
							System.out.print("numero obstacle : "+res.getInt(2));
							System.out.println(" coordonn�es : "+res.getString(1));
						}
					}
					while (res2.next()){
						for (int i = 1; i<metadata2.getColumnCount();i++){
							System.out.print("numero obstacle : "+res2.getInt(1));
							System.out.println(" nombre mesures : "+res2.getInt(2));
						}
					}
					
					res.close();
					res2.close();
					st.close();
					st2.close();
					cn.close();
			    
			} 
				
		catch (ClassNotFoundException e) {
				    e.printStackTrace();
			} 
		catch (SQLException e) {
				    e.printStackTrace();
			}     
		}

}

