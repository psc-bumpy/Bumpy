
public class Test2 {

	public static void main(String[] args) {
		
		GPS_position gps1 = new GPS_position(52.0, 32.0);
		GPS_position gps2 = new GPS_position(new double []{52.0, 1.0});
		GPS_position gps3 = new GPS_position(10.0, 10.0);
		GPS_position gps4 = new GPS_position(45.000000001, 32.00000000001);
		
		System.out.println("gps1 "+gps1.BdDtoString()+" est egal � gps2 "+gps2.BdDtoString()+" : "+gps1.isEqual(gps2)+"");
		System.out.println("gps1 "+gps1.BdDtoString()+" est egal � gps3 "+gps3.BdDtoString()+" : "+gps1.isEqual(gps3)+"");
		System.out.println("gps1 "+gps1.BdDtoString()+" est egal � gps4 "+gps4.BdDtoString()+" : "+gps1.isEqual(gps4)+"");
		System.out.println("gps1 "+gps1.BdDtoString()+" est egal � gps1 "+gps1.BdDtoString()+" : "+gps1.isEqual(gps1)+"");
	}
	
}
